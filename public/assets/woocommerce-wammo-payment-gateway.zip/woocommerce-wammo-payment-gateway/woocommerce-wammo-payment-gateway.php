<?php
/* @wordpress-plugin
 * Plugin Name:       WooCommerce WammoPay Payment Gateway
 * Plugin URI:        https://codezuke.com/support/
 * Description:       New Released WammoPay payment gateway plugin for Woocommerce.
 * Version:           1.1.0
 * WC requires at least: 2.6
 * WC tested up to: 3.5
 * Author:            Codezuke
 * Author URI:        https://codezuke.com
 * Text Domain:       woocommerce-wammo-payment-gateway
 * Domain Path: /languages
 * License:           GPL-2.0+
 * License URI:       codezuke.txt
 */

$active_plugins = apply_filters('active_plugins', get_option('active_plugins'));
if(wpruby_custom_payment_is_woocommerce_active()){
	add_filter('woocommerce_payment_gateways', 'add_wammo_payment_gateway');
	function add_wammo_payment_gateway( $gateways ){
		$gateways[] = 'WC_Wammo_payment_Gateway';
		return $gateways; 
	}

	add_action('plugins_loaded', 'init_wammo_payment_gateway');
	function init_wammo_payment_gateway(){
		require 'class-woocommerce-wammo-payment-gateway.php';
	}

	add_action( 'plugins_loaded', 'wammo_payment_load_plugin_textdomain' );
	function wammo_payment_load_plugin_textdomain() {
	  load_plugin_textdomain( 'woocommerce-wammo-payment-gateway', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
	}



}


/**
 * @return bool
 */
function wpruby_custom_payment_is_woocommerce_active()
{
	$active_plugins = (array) get_option('active_plugins', array());

	if (is_multisite()) {
		$active_plugins = array_merge($active_plugins, get_site_option('active_sitewide_plugins', array()));
	}

	return in_array('woocommerce/woocommerce.php', $active_plugins) || array_key_exists('woocommerce/woocommerce.php', $active_plugins);
}