<?php 
class WC_Wammo_Payment_Gateway extends WC_Payment_Gateway{

	public function __construct(){
		$this->id = 'wammo_payment';
		$this->method_title = __('WammoPay Payment','woocommerce-wammo-payment-gateway');
		$this->title = __('WammoPay Payment','woocommerce-wammo-payment-gateway');
		$this->has_fields = true;
		$this->init_form_fields();
		$this->init_settings();
		$this->enabled = $this->get_option('enabled');
		//$this->wammopay_test_mode = $this->get_option('wammopay_test_mode');
		$this->title = $this->get_option('title');
		$this->wammopay_api_key = $this->get_option('wammopay_api_key');
		$this->description = $this->get_option('description');
		$this->hide_text_box = $this->get_option('hide_text_box');

		add_action('woocommerce_update_options_payment_gateways_'.$this->id, array($this, 'process_admin_options'));
	}
	public function init_form_fields(){
				$this->form_fields = array(
					'enabled' => array(
					'title' 		=> __( 'Enable/Disable', 'woocommerce-wammo-payment-gateway' ),
					'type' 			=> 'checkbox',
					'label' 		=> __( 'Enable WammoPay Payment', 'woocommerce-wammo-payment-gateway' ),
					'default' 		=> 'yes'
					),
					'wammopay_api_key' => array(
						'title' 		=> __( 'API Key', 'woocommerce-wammo-payment-gateway' ),
						'type' 			=> 'text',
						'description' 	=> __( 'API key for WammoPay Payment Gateway', 'woocommerce-wammo-payment-gateway' ),
						'default'		=> "API Key",
						'desc_tip'		=> true,
					),
					'title' => array(
						'title' 		=> __( 'Method Title', 'woocommerce-wammo-payment-gateway' ),
						'type' 			=> 'text',
						'description' 	=> __( 'This controls the title', 'woocommerce-wammo-payment-gateway' ),
						'default'		=> __( 'WammoPay Payment', 'woocommerce-wammo-payment-gateway' ),
						'desc_tip'		=> true,
					),
					'description' => array(
						'title' => __( 'Customer Message', 'woocommerce-wammo-payment-gateway' ),
						'type' => 'textarea',
						'css' => 'width:500px;',
						'default' => 'Customer Note',
						'description' 	=> __( 'The message which you want it to appear to the customer in the checkout page.', 'woocommerce-wammo-payment-gateway' ),
					),
					'hide_text_box' => array(
						'title' 		=> __( 'Hide The Payment Field', 'woocommerce-wammo-payment-gateway' ),
						'type' 			=> 'checkbox',
						'label' 		=> __( 'Hide', 'woocommerce-wammo-payment-gateway' ),
						'default' 		=> 'no',
						'description' 	=> __( 'If you do not need to show the text box for customers at all, enable this option.', 'woocommerce-wammo-payment-gateway' ),
					),

			 );
	}
	/**
	 * Admin Panel Options
	 * - Options for bits like 'title' and availability on a country-by-country basis
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_options() {
		?>
		<h3><?php _e( 'WammoPay Payment Settings', 'woocommerce-wammo-payment-gateway' ); ?></h3>
			<div id="poststuff">
				<div id="post-body" class="metabox-holder columns-2">
					<div id="post-body-content">
						<table class="form-table">
							<?php $this->generate_settings_html();?>
						</table><!--/.form-table-->
					</div>
					<div id="postbox-container-1" class="postbox-container">
	                        <div id="side-sortables" class="meta-box-sortables ui-sortable"> 
	                           
     							<?php /*?><div class="postbox ">
	                                <div class="handlediv" title="Click to toggle"><br></div>
	                                <h3 class="hndle"><span><i class="dashicons dashicons-update"></i>&nbsp;&nbsp;Upgrade to Pro</span></h3>
	                                <div class="inside">
	                                    <div class="support-widget">
	                                        <ul>
	                                            <li>» Full Form Builder</li>
	                                            <li>» Custom Gateway Icon</li>
	                                            <li>» Order Status After Checkout</li>
	                                            <li>» Custom API Requests</li>
	                                            <li>» Debugging Mode</li>
	                                            <li>» Auto Hassle-Free Updates</li>
	                                            <li>» High Priority Customer Support</li>
	                                        </ul>
											<a href="https://wpruby.com/plugin/woocommerce-custom-payment-gateway-pro/" class="button wpruby_button" target="_blank"><span class="dashicons dashicons-star-filled"></span> Upgrade Now</a> 
	                                    </div>
	                                </div>
	                            </div><?php */?>
	                            

	                        </div>
	                    </div>
                    </div>
				</div>
				<div class="clear"></div>
				<style type="text/css">
				.wpruby_button{
					background-color:#4CAF50 !important;
					border-color:#4CAF50 !important;
					color:#ffffff !important;
					width:100%;
					padding:5px !important;
					text-align:center;
					height:35px !important;
					font-size:12pt !important;
				}
				</style>
				<?php
	}
	public function process_payment( $order_id ) {
		global $woocommerce;
		
		$order = new WC_Order( $order_id );
		$order_data = $order->get_data();
		
		$order_currency = $order_data['currency'];
		$order_total = $order_data['total'];
		
		$order_billing_address_1 = $order_data['billing']['address_1'];
		$order_billing_city = $order_data['billing']['city'];
		$order_billing_state = $order_data['billing']['state'];
		$order_billing_country = $order_data['billing']['country'];
		$order_billing_postcode = $order_data['billing']['postcode'];
		$order_billing_phone = $order_data['billing']['phone'];
		$order_billing_email = $order_data['billing']['email'];
		if($order_billing_email=='')
		{
			$order_billing_address_1 = $_POST['billing_address_1'];
			$order_billing_city = $_POST['billing_city'];
			$order_billing_state = $_POST['billing_state'];
			$order_billing_country = $_POST['billing_country'];
			$order_billing_postcode = $_POST['billing_postcode'];
			$order_billing_phone = $_POST['billing_phone'];
			$order_billing_email = $_POST['billing_email'];
		}
		
		//Payment gateway code
		$data_array =  array(
			  "Card"         => array(
					"Name"            => $_POST[$this->id.'-cardholder'],
					"Number"          => $_POST[$this->id.'-cardno'],
					"ExpirationMonth" => $_POST[$this->id.'-expmonth'],
					"ExpirationYear"  => $_POST[$this->id.'-expyear'],
					"CVV"             => $_POST[$this->id.'-cvv'],
					"Address1"        => $order_billing_address_1,
					"City"            => $order_billing_city,
					"State"           => $order_billing_state,
					"Country"         => $order_billing_country,
					"ZipCode"         => $order_billing_postcode,
					"Phone"           => $order_billing_phone,
					"Email"           => $order_billing_email
			  ),
			  "Charge"         => array(
					"Amount"         => $order_total,
					"CurrencyType"   => $order_currency,
					"Description"    => "Wammo Payment"
			  ),
		);
		$make_call = $this->callAPI('https://piropay-api.demo-server.ml/v1/bill', json_encode($data_array));
		$response = json_decode($make_call, true);
		if($response)
		{
			if($response['Data']['Status'] == '1')
			{
				$order->update_status('completed', __( 'Order fulfilled and complete', 'woocommerce-wammo-payment-gateway' ));
			}
			else
			{
				$order->update_status('failed', __( 'Payment failed', 'woocommerce-wammo-payment-gateway' ));
				wc_add_notice( 'ErrorMessage - '.$response['Data']['ErrorMessage'], 'error' );
			}
		}
		else
		{
			wc_add_notice( "wammopay payment Failed", 'error' );
			$order->update_status('on-hold', __( 'Awaiting payment', 'woocommerce-wammo-payment-gateway' ));
		}
		//
		
		// Reduce stock levels
		wc_reduce_stock_levels( $order_id );
		if(isset($_POST[ $this->id.'-admin-note']) && trim($_POST[ $this->id.'-admin-note'])!=''){
			$order->add_order_note(esc_html($_POST[ $this->id.'-admin-note']."Response Data : ".$make_call),1);
			//$order->add_order_note(esc_html(json_encode($_POST)),1);
		}
		// Remove cart
		$woocommerce->cart->empty_cart();
		// Return thankyou redirect
		if($response['Data']['Status'] == '2')
		{
			$checkout_url = $woocommerce->cart->get_checkout_url();
			$r_url = $checkout_url.'/order-pay/'.$order_id.'/?pay_for_order=true&key='.$order_data['order_key'];	
			return array(
				'result' => 'success',
				'redirect' => $r_url
			);
		}
		else
		{
			return array(
				'result' => 'success',
				'redirect' => $this->get_return_url( $order )
			);	
		}
	}

	public function payment_fields(){
		
		if($this->hide_text_box !== 'yes'){
			$plugins_url = plugins_url();
	    ?>

		<fieldset>
			<p class="form-row form-row-wide">
            <?php if($this->wammopay_api_key == "API Key"){echo "Please set Api Key first.";}else{?>
            <div class="col-md-12">
            <div class="col-md-6" style="float:left;">
            <img src="<?php echo $plugins_url?>/woocommerce-wammo-payment-gateway/images/WPay.png" class="wammopay-visa-icon wammopay-icon" alt="WammoPay">
            </div>
            <div class="col-md-6" style="float:left;">
            <button type="button" class="button alt wammopay-payment">Continue to payment</button>
            </div>
            </div>
            <?php }?>
            <div style="display:none;">
				<label for="<?php echo $this->id; ?>-admin-note"><?php echo ($this->description); ?> <span class="required">*</span></label>
				<textarea id="<?php echo $this->id; ?>-admin-note" class="input-text" type="text" name="<?php echo $this->id; ?>-admin-note">Wammo Pay Payment -</textarea>
            </div>    
                
			</p>						
			<div class="clear"></div>
            <div id="WammoPay_payment_div" style="display:none;">
            <div class="wammo_header">
            <div class="WammoPayClose">x</div>
            	<span class="wammo_head_text">WammoPay</span>
            	<p style="font-size:12px; margin:0;">By Jonathon Deo</p>
            </div>    
            <hr />
            
            <div class="WammoPay_content">
            <p class="form-row form-row-wide">
            	<label for="<?php echo $this->id; ?>-cardholder" class="">Card Holder</label>
                <span class="woocommerce-input-wrapper">
                <input type="text" class="input-text " name="<?php echo $this->id; ?>-cardholder" id="<?php echo $this->id; ?>-cardholder" placeholder="Card holder Name" value="" autocomplete="">
                </span>
            </p>
            <p class="form-row form-row-wide">
            	<label for="<?php echo $this->id; ?>-cardno" class="">Card Number</label>
                <span class="woocommerce-input-wrapper">
                <input type="text" class="input-text " name="<?php echo $this->id; ?>-cardno" id="<?php echo $this->id; ?>-cardno" placeholder="Card Number" value="" autocomplete="">    
                </span>
            </p>
            <p class="form-row form-row-wide">
            	<label for="<?php echo $this->id; ?>-expmonth" class="">Month</label>
                <span class="woocommerce-input-wrapper">
                <input type="text" class="input-text third" name="<?php echo $this->id; ?>-expmonth" id="<?php echo $this->id; ?>-expmonth" placeholder="Month" value="" autocomplete="">
                
                 <input type="text" class="input-text third" name="<?php echo $this->id; ?>-expyear" id="<?php echo $this->id; ?>-expyear" placeholder="Year" value="" autocomplete="">
               
                 <input type="text" class="input-text third" name="<?php echo $this->id; ?>-cvv" id="<?php echo $this->id; ?>-cvv" placeholder="CVV" value="" autocomplete="">
                </span>
            </p>
            <p class="form-row form-row-wide error-msg" style="display:none;">
            	<span style="color:#F00;">Please fill all information.</span>
            </p>
            <p class="form-row form-row-wide">
            	<span class="woocommerce-input-wrapper">
                <input type="button" class="wammoPayBtn" value="Pay <?php echo $order_currency.$order_total?>">
                </span>
            </p>
            <div class="clear"></div>
            </div>
            </div>
		</fieldset>
<div class="wammopayPopup_background"></div>        
<script>
jQuery(document).ready(function (){
	jQuery('.wammoPayBtn').click(function(){
		var cardholder = jQuery('#wammo_payment-cardholder').val();
		var cardno = jQuery('#wammo_payment-cardno').val();
		var cardmonth = jQuery('#wammo_payment-expmonth').val();
		var cardyear = jQuery('#wammo_payment-expyear').val();
		var cardcvv = jQuery('#wammo_payment-cvv').val();
		if(cardholder!='' && cardno!='' && cardmonth!='' && cardyear!='' && cardcvv!='')
		{
			jQuery('#place_order').click();
			jQuery('.wammopayPopup_background').fadeOut();
			jQuery('#WammoPay_payment_div').fadeOut();
			jQuery('.error-msg').fadeOut();
		}
		else
		{
			jQuery('.error-msg').fadeIn();
		}
	});
	jQuery('.WammoPayClose').click(function(){
		jQuery('#WammoPay_payment_div').fadeOut();
		jQuery('.wammopayPopup_background').fadeOut();
		jQuery('.error-msg').fadeOut();
	});
	jQuery('.wammopay-payment').click(function(){
		jQuery('.wammopayPopup_background').fadeIn();
		jQuery('#WammoPay_payment_div').fadeIn();
	});
	jQuery('input[name="payment_method"]').click(function(){
		switchBtn();
	});
});
function switchBtn()
{
	if(jQuery('#payment_method_wammo_payment').prop("checked") == true)
	{
		jQuery('#place_order').hide();
	}
	else
	{
		jQuery('#place_order').show();
	}
}
switchBtn();
</script>        
<style>
hr{ padding:0; margin:0;}
#WammoPay_payment_div{ 
    position: fixed;
    left: 34%;
    top: 25%;
    background: #fff;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    width: 30%;
	z-index:1;
}
#WammoPay_payment_div .input-text{
	    border-radius: 5px;
    height: 32px;
    font-size: 12px;
    box-shadow: none;
    border: 1px solid #c7c1c6;
}
#WammoPay_payment_div label{ display:none;}
#WammoPay_payment_div .third{ width: 32%; margin: 0 !important;}
.WammoPay_content{ padding:20px;}
.wammo_header{ text-align:center;padding: 10px 0;}	
.wammo_head_text{ font-size:24px; color:#5B6FD0; font-weight:bold;}
.wammoPayBtn{    border-radius: 5px !important;
    background: #5B6FD0 !important;
    font-size: 12px;
    float: right;
    margin: 0 !important;
    text-transform: unset !important;
    color: #fff !important;
    height: 28px;
    width: 46px !important;
    padding: 0 !important;
    font-weight: bold !important;}
.wammopay-icon{ width:100px; cursor:pointer; max-height: 100% !important;}
.WammoPayClose{    cursor: pointer;
    text-align: right;
    position: absolute;
    float: right;
    width: 100%;
    padding-right: 16px;
    font-family: cursive;}	
.wammopayPopup_background {
      width: 100%;
    background: #fff;
    position: fixed;
	  margin: auto;
	  top: 0;
	  bottom: 0;
	  left: 0;
	  right: 0;
    opacity: 0.5;
	display:none;
}
.wammopay-payment{margin: 5px 20px !important;}
@media only screen and (max-width:769px) and (min-width: 320px)  {
#WammoPay_payment_div {
    position: fixed;
    left: 0%;
    top: 10%;
    background: #fff;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    width: 84%;
    z-index: 1;
    margin: 0 30px;
}
#WammoPay_payment_div .third {
    width: 32%;
}
.form-row-wide{margin-bottom: 5px !important;}
.wammopay-payment{font-size: 10px !important;}
}
</style>        
		<?php
		}
	}
	
	public function callAPI($url, $data){
		$apiKey = $this->wammopay_api_key;
	   	$curl = curl_init();
	   	curl_setopt($curl, CURLOPT_POST, 1);
	   	curl_setopt($curl, CURLOPT_POSTFIELDS, $data);     
	
	   	// OPTIONS:
	   	curl_setopt($curl, CURLOPT_URL, $url);
	   	curl_setopt($curl, CURLOPT_HTTPHEADER, array(
		  'X-ApiKey: '.$apiKey,
		  'Content-Type: application/json',
	   	));
	   	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	   	curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	
	   // EXECUTE:
	   $result = curl_exec($curl);
	   if(!$result){$result=0;}
	   curl_close($curl);
	   return $result;
	}
}